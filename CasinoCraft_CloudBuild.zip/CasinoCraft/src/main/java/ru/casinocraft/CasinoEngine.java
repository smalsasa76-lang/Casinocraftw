package ru.casinocraft;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class CasinoEngine {
    private static final int COOLDOWN_TICKS = 8;
    private static final int BASE_WIN_CHANCE = 60;
    private CasinoEngine() {}

    public static boolean allowAction(ServerPlayerEntity player, String action) {
        long now = player.getServerWorld().getTime();
        if (CasinoState.isOnCooldown(player)) {
            player.sendMessage(Text.literal("§7Крупье ещё тасует карты..."), true);
            return false;
        }
        CasinoState.setLastRoll(player, now + COOLDOWN_TICKS);
        int addiction = CasinoState.addiction(player, 1);
        int chance = Math.max(15, BASE_WIN_CHANCE - addiction / 5);
        int roll = player.getRandom().nextInt(100) + 1;

        if (roll <= chance) {
            int reward = player.getRandom().nextInt(4);
            player.sendMessage(Text.literal("§a♠ ВЫИГРЫШ! §fИспытание: " + action + ". Шанс " + chance + "%."), true);
            if (reward == 0) {
                player.addExperience(1 + player.getRandom().nextInt(4));
            } else if (reward == 1) {
                player.getHungerManager().add(2, 0.3f);
            } else if (reward == 2) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 20 * 30, 0));
            } else {
                player.giveItemStack(new ItemStack(CasinoCraft.CASINO_COIN, 1 + player.getRandom().nextInt(2)));
            }
            if (addiction >= 50) player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 40, 0));
            return true;
        }

        applyPenalty(player);
        int debt = CasinoState.addDebt(player, 1 + player.getRandom().nextInt(3));
        player.sendMessage(Text.literal("§c♣ ПРОИГРЫШ! §f" + action + " сорвалось. Долг казино: " + debt + ". Зависимость: " + addiction + "/100."), true);
        return false;
    }

    private static void applyPenalty(ServerPlayerEntity player) {
        int addiction = CasinoState.addAddiction(player, 2);
        if (addiction >= 80) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 20 * 90, 1));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20 * 90, 1));
            return;
        }
        switch (player.getRandom().nextInt(6)) {
            case 0 -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20 * 45, 1));
            case 1 -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 20 * 8, 0));
            case 2 -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 20 * 60, 1));
            case 3 -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 20 * 45, 1));
            case 4 -> {
                int slot = player.getRandom().nextInt(player.getInventory().size());
                ItemStack stack = player.getInventory().getStack(slot);
                if (!stack.isEmpty()) player.dropItem(stack.split(1), true, false);
                else player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 20 * 15, 0));
            }
            default -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.UNLUCK, 20 * 60, 0));
        }
    }

    public static void roulette(ServerPlayerEntity player, int guess) {
        int result = player.getRandom().nextInt(37);
        if (guess == result) {
            player.giveItemStack(new ItemStack(CasinoCraft.CASINO_COIN, 12));
            player.sendMessage(Text.literal("§6РУЛЕТКА: выпало " + result + "! Джекпот: +12 жетонов."), false);
        } else {
            CasinoState.addDebt(player, 2);
            CasinoState.addAddiction(player, 3);
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.UNLUCK, 20 * 45, 0));
            player.sendMessage(Text.literal("§cРУЛЕТКА: выпало " + result + ". Ты проиграл 2 жетона долга."), false);
        }
    }
}
