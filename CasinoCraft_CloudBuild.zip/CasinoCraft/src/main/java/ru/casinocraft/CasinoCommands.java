package ru.casinocraft;

import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public final class CasinoCommands {
    private CasinoCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("casino")
                .then(CommandManager.literal("play").executes(context -> {
                    var player = context.getSource().getPlayerOrThrow();
                    return CasinoEngine.allowAction(player, "добровольную ставку") ? Command.SINGLE_SUCCESS : 0;
                }))
                .then(CommandManager.literal("status").executes(context -> {
                    var p = context.getSource().getPlayerOrThrow();
                    p.sendMessage(Text.literal("§6CasinoCraft §7| Зависимость: §e" + CasinoState.addiction(p)
                            + "/100 §7| Долг: §c" + CasinoState.debt(p) + " §7| Квест: §b"
                            + (CasinoState.questStep(p) + 1) + "/4"), false);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(CommandManager.literal("roulette")
                    .then(CommandManager.argument("number", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 36))
                        .executes(context -> {
                            var p = context.getSource().getPlayerOrThrow();
                            CasinoEngine.roulette(p, com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "number"));
                            return Command.SINGLE_SUCCESS;
                        })))
                .then(CommandManager.literal("repay")
                    .then(CommandManager.argument("amount", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 9999))
                        .executes(context -> {
                            var p = context.getSource().getPlayerOrThrow();
                            int amount = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "amount");
                            int debt = CasinoState.debt(p);
                            int paid = Math.min(amount, debt);
                            if (paid > 0 && p.getInventory().count(CasinoCraft.CASINO_COIN) >= paid) {
                                p.getInventory().remove(stack -> stack.isOf(CasinoCraft.CASINO_COIN), paid);
                                CasinoState.addDebt(p, -paid);
                                p.sendMessage(Text.literal("§aТы погасил " + paid + " долга."), false);
                            } else {
                                p.sendMessage(Text.literal("§cНедостаточно жетонов или долг уже погашен."), false);
                            }
                            return Command.SINGLE_SUCCESS;
                        })))
                .then(CommandManager.literal("quest").executes(context -> {
                    var p = context.getSource().getPlayerOrThrow();
                    int step = CasinoState.questStep(p);
                    String[] tasks = {"Сделай первую ставку: /casino play", "Угадай число в рулетке: /casino roulette <0-36>",
                            "Собери 3 жетона казино.", "Погаси хотя бы 1 жетон долга: /casino repay <число>"};
                    p.sendMessage(Text.literal("§bКвест " + (step + 1) + "/4: §f" + tasks[Math.min(step, 3)]
                            + " §7(прогресс квестов в этой версии частично ручной)"), false);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(CommandManager.literal("help").executes(context -> {
                    context.getSource().sendFeedback(() -> Text.literal(
                        "§6CasinoCraft §7| §f/casino play, status, roulette <0-36>, repay <amount>, quest"), false);
                    return Command.SINGLE_SUCCESS;
                }))
            )
        );
    }
}
