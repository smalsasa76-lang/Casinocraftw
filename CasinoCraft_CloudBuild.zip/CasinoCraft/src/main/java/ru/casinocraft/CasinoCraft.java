package ru.casinocraft;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.ActionResult;
import net.minecraft.text.Text;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class CasinoCraft implements ModInitializer {
    public static final String MOD_ID = "casinocraft";
    public static final Item LUCKY_CHIP = registerItem("lucky_chip", new Item(new Item.Settings()));
    public static final Item DEBT_TOKEN = registerItem("debt_token", new Item(new Item.Settings()));
    public static final Item CASINO_COIN = registerItem("casino_coin", new Item(new Item.Settings()));
    public static final Block SLOT_MACHINE = registerBlock("slot_machine",
            new Block(AbstractBlock.Settings.of(Material.METAL).strength(3.0f).requiresTool()));
    public static final Block ROULETTE_TABLE = registerBlock("roulette_table",
            new Block(AbstractBlock.Settings.of(Material.WOOD).strength(2.5f)));

    private static Block registerBlock(String name, Block block) {
        Identifier id = new Identifier(MOD_ID, name);
        Registry.register(Registries.BLOCK, id, block);
        Registry.register(Registries.ITEM, id, new BlockItem(block, new Item.Settings()));
        return block;
    }

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MOD_ID, name), item);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(LUCKY_CHIP);
            entries.add(DEBT_TOKEN);
            entries.add(CASINO_COIN);
            entries.add(SLOT_MACHINE);
            entries.add(ROULETTE_TABLE);
        });

        // Every successful block-breaking attempt must pass a casino roll first.
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) return true;
            return CasinoEngine.allowAction(serverPlayer, "добычу блока");
        });

        // Eating food requires a successful roll.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) {
                return TypedActionResult.pass(player.getStackInHand(hand));
            }
            if (!player.getStackInHand(hand).isFood()) {
                return TypedActionResult.pass(player.getStackInHand(hand));
            }
            boolean allowed = CasinoEngine.allowAction(serverPlayer, "приём пищи");
            return allowed ? TypedActionResult.pass(player.getStackInHand(hand))
                    : TypedActionResult.fail(player.getStackInHand(hand));
        });

        // Attacking a mob or another player also triggers a roll.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) return ActionResult.PASS;
            return CasinoEngine.allowAction(serverPlayer, "атаку") ? ActionResult.PASS : ActionResult.FAIL;
        });

        // Interacting with blocks (chests, doors, crafting tables, etc.) is risky too.
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity serverPlayer)) return ActionResult.PASS;
            return CasinoEngine.allowAction(serverPlayer, "взаимодействие с блоком")
                    ? ActionResult.PASS : ActionResult.FAIL;
        });

        CasinoCommands.register();
        System.out.println("[CasinoCraft] The house always wins... sometimes.");
    }
}
