package ru.casinocraft;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.network.ServerPlayerEntity;

final class CasinoState {
    private static final Map<UUID, Long> NEXT_ROLL = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> ADDICTION = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> DEBT = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> QUEST_STEP = new ConcurrentHashMap<>();

    private CasinoState() {}

    static boolean isOnCooldown(ServerPlayerEntity player) {
        return player.getServerWorld().getTime() < NEXT_ROLL.getOrDefault(player.getUuid(), 0L);
    }
    static void setLastRoll(ServerPlayerEntity player, long nextRoll) {
        NEXT_ROLL.put(player.getUuid(), nextRoll);
    }
    static int addiction(ServerPlayerEntity p) { return ADDICTION.getOrDefault(p.getUuid(), 0); }
    static int addAddiction(ServerPlayerEntity p, int amount) {
        int value = Math.max(0, Math.min(100, addiction(p) + amount));
        ADDICTION.put(p.getUuid(), value);
        return value;
    }
    static int debt(ServerPlayerEntity p) { return DEBT.getOrDefault(p.getUuid(), 0); }
    static int addDebt(ServerPlayerEntity p, int amount) {
        int value = Math.max(0, Math.min(9999, debt(p) + amount));
        DEBT.put(p.getUuid(), value);
        return value;
    }
    static int questStep(ServerPlayerEntity p) { return QUEST_STEP.getOrDefault(p.getUuid(), 0); }
    static void questStep(ServerPlayerEntity p, int step) { QUEST_STEP.put(p.getUuid(), step); }
}
